* KSP BLUEPRINT TEMPLATE v1.0***

This is a template that lets you make your blueprints for KSP. 

WHY SHOULD I USE THIS?

Because blueprints look cool!  All the templates I've made are ones I actually use on my own blog:  

https://kerbalstates.wordpress.com/

I'm hoping that other intrepid Kerbonauts will use these templates to have their own fun! The open licensing should allow everyone to benefit, and hopefully contribute back all their own creations! 

OK, SO HOW DO I USE THIS?

You'll need INKSCAPE and something to capture images of your spacecraft from inside the game. I suggest Kronal Vessel Viewer (KVV)

You can find it here: https://spacedock.info/mod/1092/Kronal%20Vessel%20Viewer%20Continued

The included SVG files are designed for use with Inkscape, an open source SVG editor. 

You can download it here for all platforms KSP runs on:

https://inkscape.org/download/

Inkscape is not trivial software and requires some work to get familiar with it. Once you get good, you can do some really cool stuff. Some tutorials will help you get you started:

https://inkscape.org/en/learn/tutorials/

On Windows, SVG files are opened in Internet Explorer by default. You may need to mess with your defaults, or right-click and choose Inkscape manually.

MAN, INKSCAPE IS COMPLICATED!

It really is :P You can ask questions in the forums, but I won't be providing any learning support for this (see the disclaimer). Sorry. There are probably other programs you can use that might be easier. I don't know anything about those though.


WHERE DO I GET KVV? 

As of the creation of this mod, you can find it here:  https://spacedock.info/mod/1092/Kronal%20Vessel%20Viewer%20Continued

WHAT'S INCLUDED WITH KSP BLUEPRINT TEMPLATE

1.) KSP Blueprint Template.svg - your workspace for making Blueprints.

2.) KSP Blueprint Template Readme.txt - the file you're reading now!

3.) Some example pictures. 



DISCLAIMERS

This is provided AS IS, WITH NO WARRANTY OR SUPPORT. That said, please enjoy :)

I am not affiliated in any way with INKSCAPE, KVV, KSP, their owners, or creators. 

LICENSE

KSP Decal Template is licensed CC BY-NC-SA 4.0

https://creativecommons.org/licenses/by-nc-sa/4.0/


CHANGES

V 1.0

Initial Release. July 17 2020. 