gimp-dds 3.0.0
(C) Copyright 2004-2013 Shawn Kirst <skirst@gmail.com>

To install, extract these files to your GIMP plugins directory.
This directory is usually located at:
C:\Program Files\GIMP 2\lib\gimp\2.0\plug-ins
