Created by Aazard, using original 6000x6000 RSS Correcy skybox from Galenmacil, using method, original posted by Green Skull:

Name and format:
     

      Visor Reflectuions

      PositiveX  // skybox right face, vertically flipped

      NegativeX  // skybox left face, vertically flipped

      PositiveY  // skybox top face, vertically flipped

      NegativeY  // skybox bottom face, vertically flipped

      PositiveZ  // skybox front face, vertically flipped

      NegativeZ  // skybox back face, vertically flipped
