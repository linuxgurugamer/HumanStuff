* KSP DECAL TEMPLATE v1.0***

This is a collection of templates that let you create your own 
decals for KSP. 

WHY SHOULD I USE THIS?

Because putting stickers on rockets is fun! I like making custom graphics for my space program - it makes the launches feel unique and special. 

I post them on my wordpress blog: https://kerbalstates.wordpress.com/

I'm hoping that other intrepid Kerbonauts will use these templates to have their own fun! The open licensing should allow everyone to benefit, and hopefully contribute back all their own creations! 

OK, SO HOW DO I USE THIS?

You'll need INKSCAPE and something to put the mods in the game. I suggest CONFORMAL DECALS.  

The included SVG files are designed for use with Inkscape, an open source SVG editor. 
You can download it here for all platforms KSP runs on:

https://inkscape.org/download/

Inkscape is not trivial software and requires some work to get familiar with it. Once you get good, you can do some really cool stuff. Some tutorials will help you get you started:

https://inkscape.org/en/learn/tutorials/

On Windows, SVG files are opened in Internet Explorer by default. You may need to mess with your defaults, or right-click and choose Inkscape manually.

MAN, INKSCAPE IS COMPLICATED!

It really is :P You can ask questions in the forums, but I won't be providing any learning support for this (see the disclaimer). Sorry. There are probably other programs you can use that might be easier. I don't know anything about those though.


WHERE DO I GET CONFORMAL DECALS? 

As of the creation of this mod, you can find it here:  https://spacedock.info/mod/2451/Conformal%20Decals?

WHAT'S INCLUDED WITH KSP DECAL TEMPLATE

1.) KSP Decal Template - Craft Names.svg -   Some premade ship/aircraft names you can put on your spacecraft/airplanes. 

2.) KSP Decal Template - Long Decals.svg - Some premade livery for your ships/aircrafts.  See examples. 

3.) KSP Decal Template Readme.txt - the file you're reading now! 

4.) Examples - Exports of all the included graphics. 



DISCLAIMERS

This is provided AS IS, WITH NO WARRANTY OR SUPPORT. That said, please enjoy :)

I am not affiliated in any way with INKSCAPE, CONFORMAL DECALS, their owners, or creators. 

LICENSE

Kerbal Mission Patch Template is licensed CC BY-NC-SA 4.0

https://creativecommons.org/licenses/by-nc-sa/4.0/

SPECIAL THANKS

Thank you to cineboxandrew, the creator of Conformal Decals. His excellent mod is what inspired me to create these templates. 
I had been working on a template for editing decals for the now out of date Nebula Decals mod - it was a lot of work and when
this came along, I decided to switch over and I've loved it. 


CHANGES

V 1.0

Initial Release. July 15 2020. 