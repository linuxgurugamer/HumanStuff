gimp-normalmap 1.2.3 for GIMP 2.8
(C) Copyright 2002-2012 Shawn Kirst <skirst@gmail.com>

To install, extract the normalmap.exe file to your GIMP plugins directory.
This directory is usually located at:
C:\Program Files\GIMP 2\lib\gimp\2.0\plug-ins

Then extract the 3 dll files to your GIMP bin directory.
This directory is usually located at:
C:\Program Files\GIMP 2\bin
